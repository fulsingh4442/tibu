
class NotificationModel {
  String id;
  String title;
  String subTitle;

  NotificationModel({this.id,this.subTitle,this.title});
}