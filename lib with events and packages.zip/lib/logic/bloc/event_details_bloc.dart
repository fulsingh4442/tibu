import 'package:rxdart/rxdart.dart';

class EventDetailsBloc{

  void dispose(){

  }
}