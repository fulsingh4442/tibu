class UserProfileObserver {
  void updateUserName(String name){}
}