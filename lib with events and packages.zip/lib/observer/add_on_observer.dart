class AddOnObserver {
  void removeAddOn(int addOnId, int tableId) {}
}
