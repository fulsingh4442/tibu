import 'package:club_app/constants/constants.dart';
import 'package:club_app/constants/navigator.dart';
import 'package:club_app/constants/strings.dart';
import 'package:club_app/logic/bloc/notifications_bloc.dart';
import 'package:club_app/logic/models/notifications.dart';
import 'package:club_app/ui/utils/utils.dart';
import 'package:flutter/material.dart';
import 'package:modal_progress_hud/modal_progress_hud.dart';
import 'package:shared_preferences/shared_preferences.dart';

enum SingingCharacter { sucasa, kenjin }

SingingCharacter _character = SingingCharacter.sucasa;

class SelectBranchScreen extends StatefulWidget {
  @override
  _SelectBranchScreenState createState() => _SelectBranchScreenState();
}

class _SelectBranchScreenState extends State<SelectBranchScreen> {
  var sucasaSelected = true;
  @override
  void initState() {
    // TODO: implement initState
    fetchBaseUrl();
    super.initState();
  }

  Future<void> fetchBaseUrl() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    BASE_URL = prefs.getString(ClubApp.BASE_URLString);

    if (prefs.getString(ClubApp.BASE_URLString) == null) {
      BASE_URL = 'https://sucasa.bookbeach.club/api/';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appBackgroundColor,
      appBar: AppBar(
        title: Text(ClubApp.selectVenue),
        leading: IconButton(
          onPressed: () {
            AppNavigator.gotoLanding(context);
          },
          icon: Icon(Icons.arrow_back),
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(4.0),
          child: Column(
            children: <Widget>[
              SizedBox(
                height: 15,
              ),

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  //sucasa
                  InkWell(
                    onTap: () {
                      setState(() {
                        sucasaSelected = true;
                        BASE_URL = 'https://sucasa.bookbeach.club/api/';
                      });
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        boxShadow: [
                          BoxShadow(
                            color: sucasaSelected
                                ? Colors.red
                                : Colors.grey.withOpacity(0.5),
                            spreadRadius: 5,
                            blurRadius: 7,
                            offset: Offset(0, 3), // changes position of shadow
                          ),
                        ],
                      ),
                      width: 150,
                      height: 150,
                      child: Image.asset("assets/images/logo.jpg"),
                    ),
                  ),

                  //kenjin
                  InkWell(
                    onTap: () {
                      setState(() {
                        sucasaSelected = false;
                        BASE_URL = "https://kenjin.reserveyourvenue.com/";
                      });
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        boxShadow: [
                          BoxShadow(
                            color: !sucasaSelected
                                ? Colors.red
                                : Colors.grey.withOpacity(0.5),
                            spreadRadius: 5,
                            blurRadius: 7,
                            offset: Offset(0, 3), // changes position of shadow
                          ),
                        ],
                      ),
                      width: 150,
                      height: 150,
                      child: Image.asset("assets/images/Kenjin_logo.jpeg"),
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 50,
              ),

              InkWell(
                onTap: () {
                  AppNavigator.gotoLanding(context);
                },
                child: Card(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 35, vertical: 20),
                    child: Text('Launch',
                        style: Theme.of(context)
                            .textTheme
                            .headline5
                            .apply(color: cardBackgroundColor)),
                  ),
                ),
              ),
              // Row(
              //   children: [
              //     Radio<SingingCharacter>(
              //       fillColor: MaterialStateProperty.all<Color>(Colors.grey),
              //       value: SingingCharacter.sucasa,
              //       groupValue: _character,
              //       onChanged: (SingingCharacter value) {
              //         setState(() {
              //           _character = value;
              //           BASE_URL = 'https://sucasa.bookbeach.club/api/';
              //         });
              //       },
              //     ),
              //     SizedBox(
              //       width: 20,
              //     ),
              //     Text('Sucasa',
              //         style: Theme.of(context)
              //             .textTheme
              //             .bodyMedium
              //             .apply(color: textColorDarkPrimary)),
              //     SizedBox(
              //       width: 20,
              //     ),
              //     SizedBox(
              //       width: 200,
              //       height: 150,
              //       child: Image.network(
              //           "https://images.unsplash.com/photo-1581417478175-a9ef18f210c2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80"),
              //     ),
              //     SizedBox(
              //       width: 20,
              //     ),
              //   ],
              // ),
              // SizedBox(
              //   height: 20,
              // ),
              // Row(
              //   children: [
              //     Radio<SingingCharacter>(
              //       fillColor: MaterialStateProperty.all<Color>(Colors.grey),
              //       value: SingingCharacter.kenjin,
              //       groupValue: _character,
              //       onChanged: (SingingCharacter value) {
              //         setState(() {
              //           _character = value;
              //           BASE_URL = "https://kenjin.reserveyourvenue.com/";
              //         });
              //       },
              //     ),
              //     SizedBox(
              //       width: 20,
              //     ),
              //     Text('Kenjin',
              //         style: Theme.of(context)
              //             .textTheme
              //             .bodyMedium
              //             .apply(color: textColorDarkPrimary)),
              //     SizedBox(
              //       width: 20,
              //     ),
              //     SizedBox(
              //       width: 200,
              //       height: 150,
              //       child: Image.network(
              //           "https://images.unsplash.com/photo-1578736641330-3155e606cd40?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80"),
              //     ),
              //     SizedBox(
              //       width: 20,
              //     ),
              //   ],
              // ),
            ],
          ),
        ),
      ),
    );
  }
}
